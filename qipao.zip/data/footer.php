<?php
	header("content-type:text/html;charset=utf-8");
?>
<div id="footer">
	<div class="footer_menu">
		<a href="#">关于中国旗袍网</a>  |  <a href="#">人才招聘</a>  |  <a href="#">联系我们</a>  |  <a href="#">微信公众号</a> |  <a href="#">广告赞助计划</a>  |  <a href="#">华服品牌收录</a>  | <a href="#" class="red">旗袍定制中心</a>
		</div>
		<div>
		&#169; 2005-2016 QiPaoH. All Rights Reserved. | 中国旗袍网 <a href=http://www.dedecms.com target='_blank'>Power by DedeCms</a> 版权所有<br />
		Tel：400-000-0000 | EMAIL：1095548393@qq.com | 合作与广告咨询QQ/微信号：1095548393<br />


		<img src="index/erweima.jpg" /><img src="index/footer_logo.png" alt="">
	</div>
</div>