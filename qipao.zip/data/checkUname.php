<?php
header('content-type:text/plain;charset=utf-8');
$user_name=$_REQUEST['user_name'];
$conn = mysqli_connect(SAE_MYSQL_HOST_M, SAE_MYSQL_USER, SAE_MYSQL_PASS,  SAE_MYSQL_DB, SAE_MYSQL_PORT);
$sql="SET NAMES UTF8";
$result=mysqli_query($conn,$sql);
$sql="SELECT * FROM users WHERE user_name='$user_name'";
$result=mysqli_query($conn,$sql);
if($result){
	if(count($row=mysqli_fetch_assoc($result))>0){
		echo '1'; 
	}else{
		echo '0'; 
	}
}